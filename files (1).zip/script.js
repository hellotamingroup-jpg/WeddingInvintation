'use strict';
/* ===== НАСТРОЙКИ — меняйте здесь ===== */
const weddingData = {
  date: '2027-08-27T16:00:00',            // дата и время церемонии
  ceremony: '[время]', evening: '[время]', // время (оставьте [..], пока не известно)
  venue: '[название]', address: '[адрес]', dress: '[дресс-код]',
  mapUrl: '',                              // ссылка на карту (Google/Yandex/2GIS)
  rsvpEndpoint: ''                         // URL Formspree / Google Apps Script / backend
};
// Add your licensed wedding music file:
// assets/music/wedding-music.mp3
const MUSIC_SRC = 'assets/music/wedding-music.mp3';

const $ = s => document.querySelector(s), $$ = s => [...document.querySelectorAll(s)];

/* Данные -> страница */
$$('[data-edit]').forEach(el => { const v = weddingData[el.dataset.edit]; if (v) el.textContent = v; });
const mapBtn = $('#mapBtn');
if (weddingData.mapUrl) mapBtn.href = weddingData.mapUrl;
else mapBtn.addEventListener('click', e => { e.preventDefault(); alert('Добавьте ссылку на карту в script.js (mapUrl).'); });

/* Заглушки вместо отсутствующих фото */
$$('.ph img').forEach(img => {
  const hide = () => img.classList.add('broken');
  img.addEventListener('error', hide); if (img.complete && !img.naturalWidth) hide();
});

/* Музыка */
const bgm = $('#bgm'), audioBtn = $('#audio');
let musicOk = true;
bgm.src = MUSIC_SRC; bgm.volume = 0.4;
bgm.addEventListener('error', () => { musicOk = false; });
function setAudioUI(on) { audioBtn.textContent = on ? '♪ )))' : '♪'; audioBtn.setAttribute('aria-pressed', on); audioBtn.setAttribute('aria-label', on ? 'Выключить музыку' : 'Включить музыку'); }
function playMusic() { if (!musicOk) return; bgm.play().then(() => setAudioUI(true)).catch(() => setAudioUI(false)); }
audioBtn.addEventListener('click', () => { if (bgm.paused) playMusic(); else { bgm.pause(); setAudioUI(false); } });
setAudioUI(false);

/* Открытие конверта */
const opening = $('#opening');
$('#openBtn').addEventListener('click', () => {
  opening.classList.add('opened'); playMusic();
  $('#main').hidden = false;
  setTimeout(() => { opening.classList.add('gone'); document.body.classList.remove('locked'); scrollTo(0, 0); initReveal(); }, 1300);
  setTimeout(() => opening.remove(), 2800);
}, { once: true });

/* Меню */
const menu = $('#menu'), burger = $('#burger');
burger.addEventListener('click', () => { const o = menu.classList.toggle('open'); burger.setAttribute('aria-expanded', o); });
menu.addEventListener('click', () => { menu.classList.remove('open'); burger.setAttribute('aria-expanded', false); });

/* Появление при прокрутке */
function initReveal() {
  const io = new IntersectionObserver(es => es.forEach(e => { if (e.isIntersecting) { e.target.classList.add('in'); io.unobserve(e.target); } }), { threshold: .12 });
  $$('.reveal').forEach(el => io.observe(el));
}

/* Лёгкий параллакс */
const par = $('[data-parallax]');
addEventListener('scroll', () => { if (par && scrollY < innerHeight * 1.5) par.style.transform = `translateY(${scrollY * .15}px)`; }, { passive: true });

/* Обратный отсчёт */
function tick() {
  const diff = new Date(weddingData.date) - new Date();
  if (diff <= 0) { $('#count').hidden = true; $('#cd-done').hidden = false; return false; }
  const p = n => String(n).padStart(2, '0');
  $('#cd-d').textContent = Math.floor(diff / 864e5);
  $('#cd-h').textContent = p(Math.floor(diff / 36e5) % 24);
  $('#cd-m').textContent = p(Math.floor(diff / 6e4) % 60);
  $('#cd-s').textContent = p(Math.floor(diff / 1e3) % 60);
  return true;
}
if (tick()) { const t = setInterval(() => { if (!tick()) clearInterval(t); }, 1000); }

/* Галерея: увеличение */
const lb = $('#lightbox');
$$('.gallery figure').forEach(f => f.addEventListener('click', () => {
  const img = f.querySelector('img'); if (img.classList.contains('broken')) return;
  lb.querySelector('img').src = img.src; lb.hidden = false;
}));
lb.addEventListener('click', () => { lb.hidden = true; });
addEventListener('keydown', e => { if (e.key === 'Escape') lb.hidden = true; });

/* RSVP */
const form = $('#form'), err = $('#err');
form.addEventListener('submit', async e => {
  e.preventDefault();
  const d = Object.fromEntries(new FormData(form));
  if (!d.name.trim()) return err.textContent = 'Пожалуйста, укажите ваше имя.';
  if (!(+d.guests >= 1)) return err.textContent = 'Укажите количество гостей.';
  if (!d.attend) return err.textContent = 'Пожалуйста, выберите вариант ответа.';
  err.textContent = '';
  // ПОДКЛЮЧЕНИЕ БЭКЕНДА: укажите rsvpEndpoint (Formspree, Google Apps Script, Telegram-бот через сервер)
  if (weddingData.rsvpEndpoint) {
    try {
      const r = await fetch(weddingData.rsvpEndpoint, { method: 'POST', headers: { 'Content-Type': 'application/json', Accept: 'application/json' }, body: JSON.stringify(d) });
      if (!r.ok) throw 0;
    } catch { return err.textContent = 'Не удалось отправить. Попробуйте ещё раз.'; }
  } else { console.info('RSVP (демо, не сохраняется):', d); }
  form.classList.add('hide'); $('#success').hidden = false;
});
